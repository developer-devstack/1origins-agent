/* THIS FILE WAS GENERATED AUTOMATICALLY BY PAYLOAD. MODIFY AT YOUR OWN RISK. */
import type { ServerFunctionClientArgs } from 'payload'

import { createServerFunctionClient } from '@payloadcms/tanstack-start/client'
import { createServerFn } from '@tanstack/react-start'

type LoadInput = {
  _splat?: string
  search?: Record<string, string | string[]>
}

const getConfig = async () => (await import('@payload-config')).default
const getImportMap = async () => (await import('./importMap.js')).importMap

export const loadAdminPageRSC = createServerFn({ method: 'GET' })
  .validator((data: LoadInput): LoadInput => data ?? {})
  .handler(async ({ data }) => {
    const { loadAdminPage } = await import('@payloadcms/tanstack-start/server')
    return loadAdminPage({
      config: await getConfig(),
      importMap: await getImportMap(),
      search: data.search,
      splat: data._splat,
    })
  })

export const getLayoutDataFn = createServerFn({ method: 'GET' }).handler(async () => {
  const { loadLayoutData } = await import('@payloadcms/tanstack-start/layouts')
  return loadLayoutData({ config: await getConfig(), importMap: await getImportMap() })
})

const runPayloadServerFn = createServerFn({ method: 'POST' })
  .validator((args: ServerFunctionClientArgs): ServerFunctionClientArgs => args)
  .handler(async ({ data }) => {
    const { handleServerFunctions } = await import('@payloadcms/tanstack-start/server')
    const result = await handleServerFunctions({
      args: data.args,
      config: await getConfig(),
      importMap: await getImportMap(),
      name: data.name,
    })

    // TanStack validates the adapter-sanitized result at the server-function boundary.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    return result as any
  })

export const serverFunctionHandler = createServerFunctionClient({
  runServerFn: runPayloadServerFn,
})

import type { MetaConfig } from 'payload'

import { getTranslation } from '@payloadcms/translations'

import type { GenerateEditViewMetadata } from '../API/generateAPIViewMetadata.js'

import { formatMetadata } from '../../utilities/formatMetadata.js'

/**
 * @todo Remove the type assertion. This is currently required because of how the `Metadata` type from `next` consumes the `URL` type.
 */
export const generateEditViewMetadata: GenerateEditViewMetadata = async ({
  collectionConfig,
  config,
  globalConfig,
  i18n,
  isEditing,
  isReadOnly = false,
  view = 'default',
}): Promise<MetaConfig> => {
  const { t } = i18n

  const entityLabel = collectionConfig
    ? getTranslation(collectionConfig.labels.singular, i18n)
    : globalConfig
      ? getTranslation(globalConfig.label, i18n)
      : ''

  const verb = isReadOnly
    ? t('general:viewing')
    : isEditing
      ? t('general:editing')
      : t('general:creating')

  const metaToUse: MetaConfig = {
    ...(config.admin.meta || {}),
    description: `${verb} - ${entityLabel}`,
    keywords: `${entityLabel}, Payload, CMS`,
    title: `${verb} - ${entityLabel}`,
  }

  const ogToUse: MetaConfig['openGraph'] = {
    title: `${isEditing ? t('general:edit') : t('general:edit')} - ${entityLabel}`,
    ...(config.admin.meta.openGraph || {}),
    ...((collectionConfig
      ? {
          ...(collectionConfig?.admin.meta?.openGraph || {}),
          ...(collectionConfig?.admin?.components?.views?.edit?.[view]?.meta?.openGraph || {}),
        }
      : {}) as MetaConfig['openGraph']),
    ...((globalConfig
      ? {
          ...(globalConfig?.admin.meta?.openGraph || {}),
          ...(globalConfig?.admin?.components?.views?.edit?.[view]?.meta?.openGraph || {}),
        }
      : {}) as MetaConfig['openGraph']),
  }

  return formatMetadata({
    ...metaToUse,
    openGraph: ogToUse,
    ...((collectionConfig
      ? {
          ...(collectionConfig?.admin.meta || {}),
          ...(collectionConfig?.admin?.components?.views?.edit?.[view]?.meta || {}),
        }
      : {}) as MetaConfig),
    ...((globalConfig
      ? {
          ...(globalConfig?.admin.meta || {}),
          ...(globalConfig?.admin?.components?.views?.edit?.[view]?.meta || {}),
        }
      : {}) as MetaConfig),
    serverURL: config.serverURL,
  })
}

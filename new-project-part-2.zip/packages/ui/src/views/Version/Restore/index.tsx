'use client'

import type { ClientCollectionConfig, ClientGlobalConfig, SanitizedCollectionConfig } from 'payload'

import { getTranslation } from '@payloadcms/translations'
import { formatAdminURL } from 'payload/shared'
import React, { Fragment, useCallback, useState } from 'react'
import { toast } from 'sonner'

import { Button } from '../../../elements/Button/index.js'
import { ConfirmationModal } from '../../../elements/ConfirmationModal/index.js'
import { useModal } from '../../../elements/Modal/index.js'
import * as PopupList from '../../../elements/Popup/PopupButtonList/index.js'
import { useConfig } from '../../../providers/Config/index.js'
import { useRouter } from '../../../providers/RouterAdapter/index.js'
import { useRouteTransition } from '../../../providers/RouteTransition/index.js'
import { useTranslation } from '../../../providers/Translation/index.js'
import { requests } from '../../../utilities/api.js'
import './index.css'

const baseClass = 'restore-version'
const modalSlug = 'restore-version'

type Props = {
  className?: string
  collectionConfig?: ClientCollectionConfig
  globalConfig?: ClientGlobalConfig
  label: SanitizedCollectionConfig['labels']['singular']
  originalDocID: number | string
  status?: string
  versionDateFormatted: string
  versionID: string
}

export const Restore: React.FC<Props> = ({
  className,
  collectionConfig,
  globalConfig,
  label,
  originalDocID,
  status,
  versionDateFormatted,
  versionID,
}) => {
  const {
    config: {
      routes: { admin: adminRoute, api: apiRoute },
    },
  } = useConfig()

  const { toggleModal } = useModal()
  const router = useRouter()
  const { i18n, t } = useTranslation()
  const [draft, setDraft] = useState(false)
  const { startRouteTransition } = useRouteTransition()

  const restoreMessage = t(
    globalConfig ? 'version:aboutToRestoreGlobal' : 'version:aboutToRestore',
    {
      label: getTranslation(label, i18n),
      versionDate: versionDateFormatted,
    },
  )

  const canRestoreAsDraft = status !== 'draft' && collectionConfig?.versions?.drafts

  const handleRestore = useCallback(async () => {
    let fetchURL: string
    let redirectURL: string

    if (collectionConfig) {
      fetchURL = formatAdminURL({
        apiRoute,
        path: `/${collectionConfig.slug}/versions/${versionID}?draft=${draft}`,
      })
      redirectURL = formatAdminURL({
        adminRoute,
        path: `/collections/${collectionConfig.slug}/${originalDocID}`,
      })
    }

    if (globalConfig) {
      fetchURL = formatAdminURL({
        apiRoute,
        path: `/globals/${globalConfig.slug}/versions/${versionID}?draft=${draft}`,
      })
      redirectURL = formatAdminURL({
        adminRoute,
        path: `/globals/${globalConfig.slug}`,
      })
    }

    const res = await requests.post(fetchURL, {
      headers: {
        'Accept-Language': i18n.language,
      },
    })

    if (res.status === 200) {
      const json = await res.json()
      toast.success(json.message)
      return startRouteTransition(() => router.push(redirectURL))
    } else {
      toast.error(t('version:problemRestoringVersion'))
    }
  }, [
    apiRoute,
    collectionConfig,
    globalConfig,
    i18n.language,
    versionID,
    draft,
    adminRoute,
    originalDocID,
    startRouteTransition,
    router,
    t,
  ])

  return (
    <Fragment>
      <div className={[baseClass, className].filter(Boolean).join(' ')}>
        <Button
          buttonStyle="primary"
          className={[canRestoreAsDraft && `${baseClass}__restore-as-draft-button`]
            .filter(Boolean)
            .join(' ')}
          onClick={() => toggleModal(modalSlug)}
          size="medium"
          SubMenuPopupContent={
            canRestoreAsDraft
              ? () => (
                  <PopupList.ButtonGroup>
                    <PopupList.Button onClick={() => [setDraft(true), toggleModal(modalSlug)]}>
                      {t('version:restoreAsDraft')}
                    </PopupList.Button>
                  </PopupList.ButtonGroup>
                )
              : null
          }
        >
          {t('version:restoreThisVersion')}
        </Button>
      </div>
      <ConfirmationModal
        body={restoreMessage}
        confirmingLabel={t('version:restoring')}
        heading={t('version:confirmVersionRestoration')}
        modalSlug={modalSlug}
        onConfirm={handleRestore}
      />
    </Fragment>
  )
}

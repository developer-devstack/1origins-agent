'use client'
import type { TextFieldDiffClientProps } from 'payload'

import React from 'react'

import { FieldDiffContainer } from '../../../../../elements/FieldDiffContainer/index.js'
import {
  escapeDiffHTML,
  getHTMLDiffComponents,
  unescapeDiffHTML,
} from '../../../../../elements/HTMLDiff/index.js'
import { useTranslation } from '../../../../../providers/Translation/index.js'
import './index.css'

const baseClass = 'text-diff'

function formatValue(value: unknown): {
  tokenizeByCharacter: boolean
  value: string
} {
  if (typeof value === 'string') {
    return { tokenizeByCharacter: true, value: escapeDiffHTML(value) }
  }
  if (typeof value === 'number') {
    return {
      tokenizeByCharacter: true,
      value: String(value),
    }
  }
  if (typeof value === 'boolean') {
    return {
      tokenizeByCharacter: false,
      value: String(value),
    }
  }

  if (value && typeof value === 'object') {
    return {
      tokenizeByCharacter: false,
      value: `<pre>${escapeDiffHTML(JSON.stringify(value, null, 2))}</pre>`,
    }
  }

  return {
    tokenizeByCharacter: true,
    value: undefined,
  }
}

export const Text: React.FC<TextFieldDiffClientProps> = ({
  field,
  locale,
  nestingLevel,
  valueFrom,
  valueTo,
}) => {
  const { i18n } = useTranslation()

  let placeholder = ''

  if (valueTo == valueFrom) {
    placeholder = `<span class="html-diff-no-value"><span>`
  }

  const formattedValueFrom = formatValue(valueFrom)
  const formattedValueTo = formatValue(valueTo)

  let tokenizeByCharacter = true
  if (formattedValueFrom.value?.length) {
    tokenizeByCharacter = formattedValueFrom.tokenizeByCharacter
  } else if (formattedValueTo.value?.length) {
    tokenizeByCharacter = formattedValueTo.tokenizeByCharacter
  }

  const renderedValueFrom = formattedValueFrom.value ?? placeholder
  const renderedValueTo: string = formattedValueTo.value ?? placeholder

  const { From, To } = getHTMLDiffComponents({
    fromHTML: '<p>' + renderedValueFrom + '</p>',
    fromLabel: i18n.t('version:comparingAgainst'),
    postProcess: unescapeDiffHTML,
    toHTML: '<p>' + renderedValueTo + '</p>',
    tokenizeByCharacter,
    toLabel: i18n.t('version:version'),
  })

  return (
    <FieldDiffContainer
      className={baseClass}
      From={From}
      i18n={i18n}
      label={{
        label: field.label,
        locale,
      }}
      nestingLevel={nestingLevel}
      To={To}
    />
  )
}

import type {
  PayloadRequest,
  RelationshipField,
  RelationshipFieldDiffServerProps,
  TypeWithID,
} from 'payload'

import { getTranslation, type I18nClient } from '@payloadcms/translations'
import React from 'react'

import { FieldDiffContainer } from '../../../../../elements/FieldDiffContainer/index.js'
import { getHTMLDiffComponents } from '../../../../../elements/HTMLDiff/index.js'
import { generateLabelFromValue } from './generateLabelFromValue.js'
import './index.css'

const baseClass = 'relationship-diff'

export type RelationshipValue =
  | { relationTo: string; value: number | string | TypeWithID }
  | (number | string | TypeWithID)

export const Relationship: React.FC<RelationshipFieldDiffServerProps> = ({
  field,
  i18n,
  locale,
  nestingLevel,
  parentIsLocalized,
  req,
  valueFrom,
  valueTo,
}) => {
  const hasMany =
    ('hasMany' in field && field.hasMany) ||
    // Check data structure (handles block swaps where schema may not match data)
    Array.isArray(valueFrom) ||
    Array.isArray(valueTo)
  const polymorphic = Array.isArray(field.relationTo)

  if (hasMany) {
    return (
      <ManyRelationshipDiff
        field={field}
        i18n={i18n}
        locale={locale}
        nestingLevel={nestingLevel}
        parentIsLocalized={parentIsLocalized}
        polymorphic={polymorphic}
        req={req}
        valueFrom={valueFrom as RelationshipValue[] | undefined}
        valueTo={valueTo as RelationshipValue[] | undefined}
      />
    )
  }

  return (
    <SingleRelationshipDiff
      field={field}
      i18n={i18n}
      locale={locale}
      nestingLevel={nestingLevel}
      parentIsLocalized={parentIsLocalized}
      polymorphic={polymorphic}
      req={req}
      valueFrom={valueFrom as RelationshipValue}
      valueTo={valueTo as RelationshipValue}
    />
  )
}

export const SingleRelationshipDiff: React.FC<{
  field: RelationshipField
  i18n: I18nClient
  locale: string
  nestingLevel?: number
  parentIsLocalized: boolean
  polymorphic: boolean
  req: PayloadRequest
  valueFrom: RelationshipValue
  valueTo: RelationshipValue
}> = async (args) => {
  const {
    field,
    i18n,
    locale,
    nestingLevel,
    parentIsLocalized,
    polymorphic,
    req,
    valueFrom,
    valueTo,
  } = args

  const ReactDOMServer = (await import('react-dom/server')).default

  const localeToUse =
    locale ??
    (req.payload.config?.localization && req.payload.config?.localization?.defaultLocale) ??
    'en'

  // Generate titles asynchronously before creating components
  const [titleFrom, titleTo] = await Promise.all([
    valueFrom
      ? generateLabelFromValue({
          field,
          locale: localeToUse,
          parentIsLocalized,
          req,
          value: valueFrom,
        })
      : Promise.resolve(null),
    valueTo
      ? generateLabelFromValue({
          field,
          locale: localeToUse,
          parentIsLocalized,
          req,
          value: valueTo,
        })
      : Promise.resolve(null),
  ])

  const FromComponent = valueFrom ? (
    <RelationshipDocumentDiff
      field={field}
      i18n={i18n}
      locale={locale}
      parentIsLocalized={parentIsLocalized}
      polymorphic={polymorphic}
      relationTo={
        polymorphic
          ? (valueFrom as { relationTo: string; value: TypeWithID }).relationTo
          : (field.relationTo as string)
      }
      req={req}
      showPill={true}
      title={titleFrom}
      value={valueFrom}
    />
  ) : null
  const ToComponent = valueTo ? (
    <RelationshipDocumentDiff
      field={field}
      i18n={i18n}
      locale={locale}
      parentIsLocalized={parentIsLocalized}
      polymorphic={polymorphic}
      relationTo={
        polymorphic
          ? (valueTo as { relationTo: string; value: TypeWithID }).relationTo
          : (field.relationTo as string)
      }
      req={req}
      showPill={true}
      title={titleTo}
      value={valueTo}
    />
  ) : null

  const NoValue = <div className="diff-no-value">{i18n.t('general:noValue')}</div>

  let From: React.ReactNode = NoValue
  let To: React.ReactNode = NoValue

  if (FromComponent || ToComponent) {
    const fromHTML = FromComponent ? ReactDOMServer.renderToStaticMarkup(FromComponent) : '<p></p>'
    const toHTML = ToComponent ? ReactDOMServer.renderToStaticMarkup(ToComponent) : '<p></p>'

    const diff = getHTMLDiffComponents({
      fromHTML,
      toHTML,
      tokenizeByCharacter: false,
    })

    From = FromComponent ? diff.From : NoValue
    To = ToComponent ? diff.To : NoValue
  }

  return (
    <FieldDiffContainer
      className={`${baseClass}-container ${baseClass}-container--hasOne`}
      From={From}
      i18n={i18n}
      label={{ label: field.label, locale }}
      nestingLevel={nestingLevel}
      To={To}
    />
  )
}

const ManyRelationshipDiff: React.FC<{
  field: RelationshipField
  i18n: I18nClient
  locale: string
  nestingLevel?: number
  parentIsLocalized: boolean
  polymorphic: boolean
  req: PayloadRequest
  valueFrom: RelationshipValue[] | undefined
  valueTo: RelationshipValue[] | undefined
}> = async ({
  field,
  i18n,
  locale,
  nestingLevel,
  parentIsLocalized,
  polymorphic,
  req,
  valueFrom,
  valueTo,
}) => {
  const ReactDOMServer = (await import('react-dom/server')).default

  const fromArr = Array.isArray(valueFrom) ? valueFrom : []
  const toArr = Array.isArray(valueTo) ? valueTo : []

  const localeToUse =
    locale ??
    (req.payload.config?.localization && req.payload.config?.localization?.defaultLocale) ??
    'en'

  // Generate all titles asynchronously before creating components
  const [titlesFrom, titlesTo] = await Promise.all([
    Promise.all(
      fromArr.map((val) =>
        generateLabelFromValue({
          field,
          locale: localeToUse,
          parentIsLocalized,
          req,
          value: val,
        }),
      ),
    ),
    Promise.all(
      toArr.map((val) =>
        generateLabelFromValue({
          field,
          locale: localeToUse,
          parentIsLocalized,
          req,
          value: val,
        }),
      ),
    ),
  ])

  const makeNodes = (list: RelationshipValue[], titles: string[]) =>
    list.map((val, idx) => (
      <RelationshipDocumentDiff
        field={field}
        i18n={i18n}
        key={idx}
        locale={locale}
        parentIsLocalized={parentIsLocalized}
        polymorphic={polymorphic}
        relationTo={
          polymorphic
            ? (val as { relationTo: string; value: TypeWithID }).relationTo
            : (field.relationTo as string)
        }
        req={req}
        showPill={polymorphic}
        title={titles[idx]}
        value={val}
      />
    ))

  const NoValue = <div className="diff-no-value">{i18n.t('general:noValue')}</div>

  const hasFrom = fromArr.length > 0
  const hasTo = toArr.length > 0

  let From: React.ReactNode = NoValue
  let To: React.ReactNode = NoValue

  if (hasFrom || hasTo) {
    const fromNodes = hasFrom ? makeNodes(fromArr, titlesFrom) : []
    const toNodes = hasTo ? makeNodes(toArr, titlesTo) : []

    const fromHTML = hasFrom ? ReactDOMServer.renderToStaticMarkup(<>{fromNodes}</>) : ''
    const toHTML = hasTo ? ReactDOMServer.renderToStaticMarkup(<>{toNodes}</>) : ''

    const diff = getHTMLDiffComponents({
      fromHTML,
      toHTML,
      tokenizeByCharacter: false,
    })

    From = hasFrom ? diff.From : NoValue
    To = hasTo ? diff.To : NoValue
  }

  return (
    <FieldDiffContainer
      className={`${baseClass}-container ${baseClass}-container--hasMany`}
      From={From}
      i18n={i18n}
      label={{ label: field.label, locale }}
      nestingLevel={nestingLevel}
      To={To}
    />
  )
}

const RelationshipDocumentDiff = ({
  field,
  i18n,
  locale,
  parentIsLocalized,
  polymorphic,
  relationTo,
  req,
  showPill = false,
  title,
  value,
}: {
  field: RelationshipField
  i18n: I18nClient
  locale: string
  parentIsLocalized: boolean
  polymorphic: boolean
  relationTo: string
  req: PayloadRequest
  showPill?: boolean
  title: null | string
  value: RelationshipValue
}) => {
  let pillLabel: null | string = null
  if (showPill) {
    const collectionConfig = req.payload.collections[relationTo].config
    pillLabel = collectionConfig.labels?.singular
      ? getTranslation(collectionConfig.labels.singular, i18n)
      : collectionConfig.slug
  }

  return (
    <div
      className={`${baseClass}`}
      data-enable-match="true"
      data-id={
        polymorphic
          ? (value as { relationTo: string; value: TypeWithID }).value.id
          : (value as TypeWithID).id
      }
      data-relation-to={relationTo}
    >
      {pillLabel && (
        <span className={`${baseClass}__pill`} data-enable-match="false">
          {pillLabel}
        </span>
      )}
      <strong className={`${baseClass}__info`} data-enable-match="false">
        {title}
      </strong>
    </div>
  )
}

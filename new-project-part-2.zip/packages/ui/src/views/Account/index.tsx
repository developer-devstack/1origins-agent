import type { AdminViewServerProps, DocumentViewServerPropsOnly } from 'payload'

import { formatAdminURL } from 'payload/shared'
import React from 'react'

import { DocumentHeader } from '../../elements/DocumentHeader/index.js'
import { RenderServerComponent } from '../../elements/RenderServerComponent/index.js'
/* eslint-disable payload/no-imports-from-exports-dir -- Server component must reference exports/client bundle for proper client boundary in prod builds */
import {
  AccountClient,
  DefaultEditView,
  DocumentInfoProvider,
  EditDepthProvider,
  HydrateAuthProvider,
} from '../../exports/client/index.js'
/* eslint-enable payload/no-imports-from-exports-dir */
import { buildFormState } from '../../utilities/buildFormState.js'
import { getDocPreferences } from '../../utilities/getDocPreferences.js'
import { getDocumentData } from '../../utilities/getDocumentData.js'
import { getDocumentPermissions } from '../../utilities/getDocumentPermissions.js'
import { getIsLocked } from '../../utilities/getIsLocked.js'
import { getVersions } from '../../utilities/getVersions.js'
import { Settings } from './Settings/index.js'

export async function AccountView({
  initPageResult,
  params,
  searchParams,
  user: userWithReadAccess,
}: AdminViewServerProps) {
  const {
    languageOptions,
    locale,
    permissions,
    req,
    req: {
      i18n,
      payload,
      payload: { config },
      user,
    },
  } = initPageResult

  const {
    admin: { theme, user: userSlug },
    routes: { api },
  } = config

  const collectionConfig = payload?.collections?.[userSlug]?.config

  if (collectionConfig && user?.id) {
    // Fetch the data required for the view
    const data = await getDocumentData({
      id: user.id,
      collectionSlug: collectionConfig.slug,
      locale,
      payload,
      req,
      user,
    })

    if (!data) {
      throw new Error('not-found')
    }

    // Get document preferences
    const docPreferences = await getDocPreferences({
      id: user.id,
      collectionSlug: collectionConfig.slug,
      payload,
      user,
    })

    // Get permissions
    const {
      docPermissions,
      hasDeletePermission,
      hasPublishPermission,
      hasSavePermission,
      hasTrashPermission,
    } = await getDocumentPermissions({
      id: user.id,
      collectionConfig,
      data,
      req,
    })

    // Build initial form state from data
    const { state: formState } = await buildFormState({
      id: user.id,
      collectionSlug: collectionConfig.slug,
      data,
      docPermissions,
      docPreferences,
      locale: locale?.code,
      operation: 'update',
      renderAllFields: true,
      req,
      schemaPath: collectionConfig.slug,
      skipValidation: true,
      user: userWithReadAccess,
    })

    // Fetch document lock state
    const { currentEditor, isLocked, lastUpdateTime } = await getIsLocked({
      id: user.id,
      collectionConfig,
      isEditing: true,
      req,
    })

    // Get all versions required for UI
    const { hasPublishedDoc, mostRecentVersionIsAutosaved, unpublishedVersionCount, versionCount } =
      await getVersions({
        id: user.id,
        collectionConfig,
        doc: data,
        docPermissions,
        locale: locale?.code,
        payload,
        user,
      })

    return (
      <DocumentInfoProvider
        AfterFields={
          <Settings
            i18n={i18n}
            languageOptions={languageOptions}
            payload={payload}
            theme={theme}
            user={userWithReadAccess}
          />
        }
        apiURL={formatAdminURL({
          apiRoute: api,
          path: `/${userSlug}${user?.id ? `/${user.id}` : ''}`,
        })}
        collectionSlug={userSlug}
        currentEditor={currentEditor}
        docPermissions={docPermissions}
        hasDeletePermission={hasDeletePermission}
        hasPublishedDoc={hasPublishedDoc}
        hasPublishPermission={hasPublishPermission}
        hasSavePermission={hasSavePermission}
        hasTrashPermission={hasTrashPermission}
        id={user?.id}
        initialData={data}
        initialState={formState}
        isEditing
        isLocked={isLocked}
        lastUpdateTime={lastUpdateTime}
        mostRecentVersionIsAutosaved={mostRecentVersionIsAutosaved}
        unpublishedVersionCount={unpublishedVersionCount}
        versionCount={versionCount}
      >
        <EditDepthProvider>
          <DocumentHeader
            collectionConfig={collectionConfig}
            hideTabs
            permissions={permissions}
            req={req}
            user={userWithReadAccess}
          />
          <HydrateAuthProvider permissions={permissions} />
          {RenderServerComponent({
            Component: config.admin?.components?.views?.account?.Component,
            Fallback: DefaultEditView,
            importMap: payload.importMap,
            serverProps: {
              doc: data,
              hasPublishedDoc,
              i18n,
              initPageResult,
              locale,
              params,
              payload,
              permissions,
              routeSegments: [],
              searchParams,
              server: req.server,
              user: userWithReadAccess,
            } satisfies DocumentViewServerPropsOnly,
          })}
          <AccountClient />
        </EditDepthProvider>
      </DocumentInfoProvider>
    )
  }

  return req.server.notFound()
}

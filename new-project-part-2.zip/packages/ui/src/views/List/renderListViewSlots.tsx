import type {
  AfterListClientProps,
  AfterListTableClientProps,
  AfterListTableServerPropsOnly,
  BeforeListClientProps,
  BeforeListServerPropsOnly,
  BeforeListTableClientProps,
  BeforeListTableServerPropsOnly,
  ListViewServerPropsOnly,
  ListViewSlots,
  ListViewSlotSharedClientProps,
  NoResultsClientProps,
  NoResultsServerPropsOnly,
  Payload,
  PayloadRequest,
  SanitizedCollectionConfig,
  StaticDescription,
  ViewDescriptionClientProps,
  ViewDescriptionServerPropsOnly,
} from 'payload'

import React from 'react'

import { RenderServerComponent } from '../../elements/RenderServerComponent/index.js'
// eslint-disable-next-line payload/no-imports-from-exports-dir -- Server component must reference exports/client bundle for proper client boundary in prod builds
import { Banner } from '../../exports/client/index.js'
import { filterLLMInstructionsMenuItems } from '../../utilities/filterLLMInstructionsMenuItems.js'

type Args = {
  clientProps: ListViewSlotSharedClientProps
  collectionConfig: SanitizedCollectionConfig
  description?: StaticDescription
  notFoundDocId?: null | string
  payload: Payload
  req: PayloadRequest
  serverProps: ListViewServerPropsOnly
}

export const renderListViewSlots = async ({
  clientProps,
  collectionConfig,
  description,
  notFoundDocId,
  payload,
  req,
  serverProps,
}: Args): Promise<ListViewSlots> => {
  const result: ListViewSlots = {} as ListViewSlots

  if (collectionConfig.admin.components?.afterList) {
    result.AfterList = RenderServerComponent({
      clientProps: clientProps satisfies AfterListClientProps,
      Component: collectionConfig.admin.components.afterList,
      importMap: payload.importMap,
      serverProps: serverProps satisfies AfterListTableServerPropsOnly,
    })
  }

  const listMenuItems = await filterLLMInstructionsMenuItems({
    collectionSlug: collectionConfig.slug,
    menuItems: collectionConfig.admin.components?.listMenuItems,
    permissions: serverProps.permissions,
    req,
  })

  if (listMenuItems?.length) {
    result.listMenuItems = [
      RenderServerComponent({
        clientProps,
        Component: listMenuItems,
        importMap: payload.importMap,
        serverProps,
      }),
    ]
  }

  if (collectionConfig.admin.components?.afterListTable) {
    result.AfterListTable = RenderServerComponent({
      clientProps: clientProps satisfies AfterListTableClientProps,
      Component: collectionConfig.admin.components.afterListTable,
      importMap: payload.importMap,
      serverProps: serverProps satisfies AfterListTableServerPropsOnly,
    })
  }

  if (collectionConfig.admin.components?.beforeList) {
    result.BeforeList = RenderServerComponent({
      clientProps: clientProps satisfies BeforeListClientProps,
      Component: collectionConfig.admin.components.beforeList,
      importMap: payload.importMap,
      serverProps: serverProps satisfies BeforeListServerPropsOnly,
    })
  }

  // Handle beforeListTable with optional banner
  const existingBeforeListTable = collectionConfig.admin.components?.beforeListTable
    ? RenderServerComponent({
        clientProps: clientProps satisfies BeforeListTableClientProps,
        Component: collectionConfig.admin.components.beforeListTable,
        importMap: payload.importMap,
        serverProps: serverProps satisfies BeforeListTableServerPropsOnly,
      })
    : null

  // Create banner for document not found
  const notFoundBanner = notFoundDocId ? (
    <Banner className="list-view__not-found-banner" type="danger">
      {serverProps.i18n.t('error:documentNotFound', { id: notFoundDocId })}
    </Banner>
  ) : null

  // Combine banner and existing component
  if (notFoundBanner || existingBeforeListTable) {
    result.BeforeListTable = (
      <React.Fragment>
        {notFoundBanner}
        {existingBeforeListTable}
      </React.Fragment>
    )
  }

  if (collectionConfig.admin.components?.Description) {
    result.Description = RenderServerComponent({
      clientProps: {
        collectionSlug: collectionConfig.slug,
        description,
      } satisfies ViewDescriptionClientProps,
      Component: collectionConfig.admin.components.Description,
      importMap: payload.importMap,
      serverProps: serverProps satisfies ViewDescriptionServerPropsOnly,
    })
  }

  if (collectionConfig.admin.components?.views?.list?.NoResults) {
    result.NoResults = (
      <React.Fragment key="list-view-no-results">
        {RenderServerComponent({
          clientProps: clientProps satisfies NoResultsClientProps,
          Component: collectionConfig.admin.components.views.list.NoResults,
          importMap: payload.importMap,
          key: 'list-view-no-results',
          serverProps: serverProps satisfies NoResultsServerPropsOnly,
        })}
      </React.Fragment>
    )
  }

  return result
}

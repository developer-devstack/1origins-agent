import type { Field, ServerFunction, WidgetServerProps } from 'payload'

import React from 'react'

import { RenderServerComponent } from '../../../../../elements/RenderServerComponent/index.js'
import { extractLocaleData } from '../utils/localeUtils.js'

export type RenderWidgetServerFnArgs = {
  /**
   * Instance-specific data for this widget
   */
  widgetData?: Record<string, unknown>
  /**
   * The slug of the widget to render
   */
  widgetSlug: string
}

export type RenderWidgetServerFnReturnType = {
  component: React.ReactNode
}

/**
 * Server function to render a widget on-demand.
 * Similar to render-field but specifically for dashboard widgets.
 */
export const renderWidgetHandler: ServerFunction<
  RenderWidgetServerFnArgs,
  RenderWidgetServerFnReturnType
> = ({ cookies, locale, permissions, req, user, widgetData, widgetSlug }) => {
  if (!req.user) {
    throw new Error('Unauthorized')
  }

  const { widgets } = req.payload.config.admin.dashboard
  const { importMap } = req.payload

  // Find the widget configuration
  const widgetConfig = widgets.find((widget) => widget.slug === widgetSlug)

  if (!widgetConfig) {
    return {
      component: React.createElement(
        'div',
        {
          style: {
            background: 'var(--color-bg-secondary)',
            border: 'var(--stroke-width-small) solid var(--color-border)',
            borderRadius: 'var(--radius-medium)',
            color: 'var(--color-text)',
            padding: 'var(--spacer-3)',
            textAlign: 'center',
          },
        },
        `Widget "${widgetSlug}" not found`,
      ),
    }
  }

  try {
    const localeFilteredData = widgetConfig.fields?.length
      ? extractLocaleData(widgetData || {}, req.locale || 'en', widgetConfig.fields)
      : widgetData || {}

    const serverProps: WidgetServerProps = {
      cookies,
      locale,
      permissions,
      req,
      user,
      widgetData: localeFilteredData,
      widgetSlug,
    }

    // Render the widget server component
    const component = RenderServerComponent({
      Component: widgetConfig.Component,
      importMap,
      serverProps,
    })

    return { component }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error)

    req.payload.logger.error({
      err: error,
      msg: `Error rendering widget "${widgetSlug}": ${errorMessage}`,
    })

    return {
      component: React.createElement(
        'div',
        {
          style: {
            background: 'var(--color-bg-danger-tertiary)',
            border: 'var(--stroke-width-small) solid var(--color-border-danger)',
            borderRadius: 'var(--radius-medium)',
            color: 'var(--color-text-danger)',
            padding: 'var(--spacer-3)',
            textAlign: 'center',
          },
        },
        'Error loading widget',
      ),
    }
  }
}
